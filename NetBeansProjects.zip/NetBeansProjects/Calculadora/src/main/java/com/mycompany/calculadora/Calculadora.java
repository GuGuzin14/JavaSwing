/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora;

import Frames.Homescreen;

/**
 *
 * @author aluno
 */
public class Calculadora {

    public static void main(String[] args) {
        Homescreen hs = new Homescreen();
        hs.setVisible(true);
        
    }
}
